# NeuroPhenotype-ML

Reproducible machine-learning research for identifying neurotransmitter-defined neuronal populations from **in vivo extracellular single-unit recordings**.

## Research status

Early-stage research infrastructure. Predictions are **not** validated neurotransmitter identities and must not be used as molecular ground truth.

## Design principles

- Keep original recordings immutable.
- Normalize extracellular spike waveforms while preserving relative morphology.
- Evaluate waveform, firing/burst, global temporal pattern, and stability features separately.
- Split data by animal/session to avoid leakage.
- Record dataset versions, code commits, configs, metrics, and model artifacts for every experiment.
- Treat electrode type, filtering and acquisition conditions as potential confounders.
- Support an unknown/abstain outcome.

## Storage

- GitHub: tracked code, notebooks, configs, manifests, tests, documentation.
- Google Drive `NeuroPhenotype-ML/`: raw/processed datasets, checkpoints, experiment artifacts and publication files.
- Google Colab: primary execution environment; optional external GPU for larger runs.

## Setup (Colab)

Open a Colab notebook, clone the repository, then install in editable mode:

```python
!git clone https://github.com/OWNER/neurophenotype-ml.git
%cd neurophenotype-ml
!pip install -e '.[dev]'
```

Replace OWNER with the actual GitHub account. This command is a template; it will not work before the repository is created.

## Reproducibility

Every training run should save a config snapshot, Git commit hash, dataset manifest/checksums, train/validation/test group IDs, metrics and software environment. Never commit raw electrophysiology or credentials.

## Current milestones

1. Audit independently identified LC (NA) datasets and confirm whether raw spike waveforms are present.
2. Implement unified loaders and waveform alignment/normalization.
3. Build baseline waveform-only and temporal-feature models.
4. Evaluate across datasets, animals, recording methods and experimental conditions.

## License and data rights

No software license has been chosen yet; do not assume permission to redistribute datasets or reuse third-party code. Add a license when publication and ownership terms are decided.
