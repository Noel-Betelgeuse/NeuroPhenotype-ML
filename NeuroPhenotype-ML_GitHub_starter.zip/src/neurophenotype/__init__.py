"""NeuroPhenotype-ML research toolkit."""
__version__ = "0.0.1"
