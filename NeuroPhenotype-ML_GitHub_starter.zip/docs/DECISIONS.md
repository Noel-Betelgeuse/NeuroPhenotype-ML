# Decision log

## 2026-11-10: Cloud-first architecture
- Colab for interactive workflows; GitHub for source code and reviews.
- Google Drive for datasets and model/runs storage.
- Cloud GPU provider optional; no vendor-specific assumptions in training code.
- Raw recordings immutable, and no public redistribution until license verified.
- First ground-truth target: molecularly identified noradrenergic neurons.

## Pending decisions
- Repository URL and owner.
- Software licensing and IP ownership.
- Model artifact synchronization method (DVC vs explicit versioned uploads).
- Dataset audit: waveform availability and labels.
