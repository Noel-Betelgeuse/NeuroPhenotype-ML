# Storage map

Google Drive root folder: https://drive.google.com/drive/folders/1UahinboAZ6jeDY_k7oNrUa_sy3Fg4yWQ

- 01_DATASETS: originals, public/internal, manifests
- 02_PROCESSED_DATA: feature tables, normalized waveforms, temporal features, splits
- 03_MODELS: checkpoints, release candidates
- 04_EXPERIMENTS: runs, benchmarks, reports
- 05_PUBLICATION: manuscript, figures, supplementary, releases
- 06_DOCUMENTATION: protocols, dataset audit, decision log, references
- 07_BACKUPS: manual snapshots (separate backup recommended)

A folder inside Drive is not, by itself, an independent backup. Preserve at least one offline or separately administered backup for critical data.
