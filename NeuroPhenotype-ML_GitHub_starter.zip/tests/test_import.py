def test_package_import():
    import neurophenotype
    assert neurophenotype.__version__
